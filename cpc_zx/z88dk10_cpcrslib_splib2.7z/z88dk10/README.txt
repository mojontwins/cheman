This folder contains the Windows setup extension.
YOU CAN DELETE THIS FOLDER: YOU DO NOT NEED IT ANYMORE!

It is derived from the "manual setup tool", from
http://www.marcellozaniboni.net/z88dk/
If you need to move this installation to another
folder in your HDD, use that tool.

You you are curious about the executable, you can view
its source code in "main.cpp".
